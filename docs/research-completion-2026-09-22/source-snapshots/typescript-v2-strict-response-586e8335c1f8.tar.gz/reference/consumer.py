"""Bounded recovery state for a continuation whose transport outcome is uncertain."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Literal

from reference.backend import OperationIdentity
from reference.readback import EffectObservation, EffectState

SubmissionState = Literal["not_admitted", "admitted", "unknown"]
RecoveryAction = Literal["reconcile", "return_stored_result", "stop"]


@dataclass(frozen=True, slots=True)
class RecoveryState:
    identity: OperationIdentity
    submission: SubmissionState
    effect: EffectState
    observation: EffectObservation | None
    action: RecoveryAction
    fresh_write_authorized: Literal[False]
    detail: str


class ContinuationConsumer:
    """Fail closed after transport loss and permit read-only reconciliation."""

    def __init__(self, identity: OperationIdentity) -> None:
        self.identity = identity

    def transport_failed(self, error: BaseException) -> RecoveryState:
        return RecoveryState(
            identity=self.identity,
            submission="unknown",
            effect="unknown",
            observation=None,
            action="reconcile",
            fresh_write_authorized=False,
            detail=f"no terminal reply received ({type(error).__name__})",
        )

    def reconcile(self, observe: Callable[[OperationIdentity], EffectObservation]) -> RecoveryState:
        observation = observe(self.identity)
        if observation.identity != self.identity:
            raise ValueError("reconciliation observation identity does not match the attempt")
        if not observation.authoritative:
            raise ValueError("diagnostic observations cannot settle an uncertain operation")
        return RecoveryState(
            identity=self.identity,
            submission="unknown",
            effect=observation.state,
            observation=observation,
            action=("return_stored_result" if observation.state == "applied" else "stop"),
            fresh_write_authorized=False,
            detail="fresh read-only observation; no repeat execution authorized",
        )
